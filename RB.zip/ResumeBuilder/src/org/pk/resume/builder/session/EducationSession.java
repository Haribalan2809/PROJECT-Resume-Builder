package org.pk.resume.builder.session;

public class EducationSession {
	
	public static String SCHOOL_NAME = "school_name";
	public static String DEGREE = "degree";
	public static String SUBJECT = "subject";
	public static String YEAR = "year";
	public static String BOARD = "board";
	public static String OBTAINED_MARKS = "obtained_marks";
	public static String TOTAL_MARKS = "total_marks";
	public static String PERCENTAGE = "percentage";
}
