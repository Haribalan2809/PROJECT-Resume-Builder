package org.pk.resume.builder.session;

public class ExperienceSession {
	
	public static String EMPLOYER = "employer";
	public static String DESIGNATION = "designation";
	public static String JOININIG_DATE = "joining_date";
	public static String LEAVING_DATE = "leaving_date";
	public static String WORKING = "working";
	public static String EXPERIENCE = "experience";
	public static String SUBJECT_THAUGHT = "subject_thaught";
	public static String COURSE = "course";

}
